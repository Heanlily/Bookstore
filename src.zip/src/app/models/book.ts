export class Book {
  id: number;
  name: string;
  price: number;
  author: string;
  category: string;
}
